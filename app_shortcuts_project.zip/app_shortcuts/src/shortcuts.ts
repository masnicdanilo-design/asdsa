import { NativeModules } from 'react-native';
import { PluginManager } from 'sn-plugin-lib';

const { AppLauncher } = NativeModules;

export const SETUP_BUTTON_ID = 100;
export const BASE_ID = 300; // dugmad 300..307 su shortcuti
export const MAX_SHORTCUTS = 8;

export type Shortcut = { pkg: string; label: string; icon: string };
export type InstalledApp = { pkg: string; label: string };

async function dir(): Promise<string> {
  const d = await PluginManager.getPluginDirPath();
  if (!d) throw new Error('Plugin dir not available');
  return d;
}

export async function loadShortcuts(): Promise<Shortcut[]> {
  try {
    const txt: string | null = await AppLauncher.readText(`${await dir()}/shortcuts.json`);
    return txt ? JSON.parse(txt) : [];
  } catch {
    return [];
  }
}

export async function saveShortcuts(list: Shortcut[]): Promise<void> {
  await AppLauncher.writeText(`${await dir()}/shortcuts.json`, JSON.stringify(list));
}

export async function listInstalledApps(): Promise<InstalledApp[]> {
  return AppLauncher.getLaunchableApps();
}

/** Izvuče ikonu aplikacije u PNG u plugin folder i vrati putanju. */
export async function exportIcon(pkg: string): Promise<string> {
  return AppLauncher.exportIcon(pkg, `${await dir()}/icons/${pkg}.png`);
}

/** (Re)registruje shortcut dugmad u DOC context meniju (selection toolbar). */
export async function registerShortcutButtons(list: Shortcut[]): Promise<void> {
  for (let i = 0; i < MAX_SHORTCUTS; i++) {
    try { await PluginManager.unregisterButton(BASE_ID + i); } catch {}
  }
  for (let i = 0; i < Math.min(list.length, MAX_SHORTCUTS); i++) {
    const s = list[i];
    await PluginManager.registerButton(3, ['DOC'], {
      id: BASE_ID + i,
      name: s.label,
      icon: s.icon,
      showType: 0, // bez UI-ja, samo pokreni aplikaciju
    } as any);
  }
}
